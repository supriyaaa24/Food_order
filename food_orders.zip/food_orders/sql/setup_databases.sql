CREATE DATABASE IF NOT EXISTS food_orders_raw_db CHARACTER SET utf8mb4;
CREATE DATABASE IF NOT EXISTS food_orders_analytics_db CHARACTER SET utf8mb4;

USE food_orders_raw_db;

-- Raw source values are stored as text so the original CSV strings and blanks are preserved.
CREATE TABLE IF NOT EXISTS raw_food_orders (
    `Order ID` TEXT NULL,
    `Customer ID` TEXT NULL,
    `Restaurant ID` TEXT NULL,
    `Order Date and Time` TEXT NULL,
    `Delivery Date and Time` TEXT NULL,
    `Order Value` TEXT NULL,
    `Delivery Fee` TEXT NULL,
    `Payment Method` TEXT NULL,
    `Discounts and Offers` TEXT NULL,
    `Commission Fee` TEXT NULL,
    `Payment Processing Fee` TEXT NULL,
    `Refunds/Chargebacks` TEXT NULL,
    `Weather Condition` TEXT NULL,
    `Order Channel` TEXT NULL,
    source_run_id CHAR(36) NOT NULL,
    source_batch_number INT NOT NULL,
    source_row_number INT NOT NULL,
    loaded_at_utc DATETIME NOT NULL,
    INDEX ix_raw_food_orders_source_run_id (source_run_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS raw_batch_log (
    source_run_id CHAR(36) NOT NULL,
    batch_number INT NOT NULL,
    record_count INT NOT NULL,
    PRIMARY KEY (source_run_id, batch_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

USE food_orders_analytics_db;

CREATE TABLE IF NOT EXISTS cleaned_food_orders (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    source_run_id CHAR(36) NOT NULL,
    source_row_number INT NOT NULL,
    order_id VARCHAR(50) NOT NULL,
    customer_id VARCHAR(50) NULL,
    restaurant_id VARCHAR(50) NULL,
    order_datetime DATETIME NOT NULL,
    delivery_datetime DATETIME NOT NULL,
    order_value DECIMAL(12,2) NULL,
    delivery_fee DECIMAL(12,2) NULL,
    payment_method VARCHAR(100) NOT NULL,
    discounts_and_offers VARCHAR(255) NOT NULL,
    commission_fee DECIMAL(12,2) NULL,
    payment_processing_fee DECIMAL(12,2) NULL,
    refunds_chargebacks DECIMAL(12,2) NULL,
    weather_condition VARCHAR(50) NULL,
    order_channel VARCHAR(50) NULL,
    delivery_time_minutes DECIMAL(10,2) NOT NULL,
    order_date DATE NOT NULL,
    order_hour INT NOT NULL,
    platform_net_revenue DECIMAL(12,2) NULL,
    INDEX ix_cleaned_food_orders_source_run_id (source_run_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
